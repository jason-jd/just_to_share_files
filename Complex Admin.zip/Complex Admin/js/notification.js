(function($) {
    load_users();
    load_complex();
    $("#notification_for_user_btn").click(function(){
        notification_for_user();
    })
    $("#notification_for_complex_btn").click(function(){
        notification_for_complex();
    })
})(jQuery);

function load_users() {
    firebase.database().ref("/users").orderByChild("complex").equalTo(sessionStorage.username).once("value").then((user_snap)=>{
        var users = user_snap.val();
        console.log(users);
        for(var key in users){
            var fullname = users[key].first_name + " " + users[key].last_name;
            var content = '<option value="'+key+'">'+fullname+'</option>'
            $("#optUser").append(content)
        }
    }).catch(err=>{
        console.log(err);
    });
}
function load_complex() {
    firebase.database().ref("/complex").orderByChild("name").equalTo(sessionStorage.username).once("value").then((complex_snap)=>{
        var complex = complex_snap.val();
        console.log(complex);
        for(var key in complex){
            var content = '<option value="'+key+'">'+complex[key].name+'</option>'
            $("#optComplex").append(content)
        }
    }).catch(err=>{
        console.log(err);
    });
}

function notification_for_user() {
    
    $("#loading_div").show();
    //send notification first and save into the database
    var send_to = $("#optUser").val();
    var message = $("#txtNotification").val().trim();


    var to_insert = {
        sender: "sessionStorage.uid",
        message: message,
        receiver_type: "indivisual",
        receiver: send_to,
        timestamp: Date.now()
    }
    firebase.database().ref('notification').push(to_insert).then((snapshot) => {
        console.log('success')
                $("#loading_div").hide();
         $("#success_user").show();
                setTimeout(function(){
                    $("#success_user").fadeOut(700); 
                        },5000);
    }).catch(err=>{
        console.log(err)
                $("#loading_div").hide();
         $("#error_user").show();
                setTimeout(function(){
                    $("#error_user").fadeOut(700); 
                        },5000);
    })
    // var data = {
    //     ref: "/notification",
    //     message: message,
    //     sender: "sessionStorage.uid",
    //     receiver_type: "indivisual",
    //     receiver: send_to,
    //     timestamp: Date.now()
    // };
    // $.ajax({
    //     url: 'https://us-central1-access-app-d0cce.cloudfunctions.net/insert_notification',
    //     dataType: "json",
    //     method: 'POST',
    //     crossDomain: true,
    //     data: {original:data},
    //     success: function(data){
    //       console.log('succes: '+JSON.stringify(data));
    //     },
    //     error: function(jqXHR, textStatus, errorThrown){
    //         console.log('jqXHR: '+JSON.stringify(jqXHR)); 
    //         console.log('textStatus: '+(textStatus)); 
    //         console.log('errorThrown: '+(errorThrown)); 
    //     }
    // })
}

function notification_for_complex() {
    //send notification first and save into the database
    $("#loading_div").show();
    var send_to = $("#optComplex").val();
    var message = $("#txtNotification").val().trim();
    var data = {
        message: message,
        sender: "sessionStorage.uid",
        receiver_type: "complex",
        receiver: send_to,
        receiver_name: $("#optComplex option:selected").text(),
        timestamp: Date.now()
    };
    firebase.database().ref("/notification").push(data).then(()=>{
        $("#txtNotification").val("");
        console.log("notification sent to " + send_to);
            $("#loading_div").hide();
         $("#success_complex").show();
                setTimeout(function(){
                    $("#success_complex").fadeOut(700); 
                        },5000);    
    }).catch(err=>{
        console.log(err);
            $("#loading_div").hide();
         $("#error_complex").show();
                setTimeout(function(){
                    $("#error_complex").fadeOut(700); 
                        },5000);    
    });
}