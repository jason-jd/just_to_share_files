<?php
include("../includes/connection.php");


$JSON = json_decode($_POST['myUser']);

$codeID = $JSON->txtVisitor;
$qrcode = $JSON->txtUses;

 $sqlu = "SELECT * FROM access_code WHERE ID = '$codeID' ";
 $resultu=mysqli_query($conn,$sqlu);
 $rowu=mysqli_fetch_array($resultu);
 $qrchecker = $rowu['QR_Code'];
 $timedate = date("Y-m-d H:i:s");
 $complexid = "1";




if($qrcode == $qrchecker)
{
$sql = "INSERT INTO access_use('Time', 'Complex_ID', 'Access_Code_ID') VALUES(?,?,?)";
$insertStmt = $conn->prepare($sql) or die(mysqli_error($conn));
$insertStmt ->bind_param("sii",$timedate,$complexid,$codeID);
$insertStmt->execute() or die(mysqli_error($conn));

$state = "Green Light!";
}
else
{
	$state = "Red Light!";
}

echo $state;
?>