$(document).ready(function(){
    user.start();
})

var user = {
    'start':function(){
        var main = this;
        console.log('start');
        main.fetchTypes();
        main.attachUserSave();
        main.disableComplex();
    },
    'flag':{
        'usertype'  :false,
        'complex'   :false
    },
    'register':function(){
        $("#loading_div").show();

        var person = {
            'first_name'            :$('#txtName').val().trim(),
            'last_name'             :$('#txtSurname').val().trim(),
            'telephone'             :$('#txtTelephone').val().trim(),
            'id'                    :$('#txtIDNO').val().trim(),
            'street_address'        :$('#txtAddress').val().trim(),
            'vehicle_number'        :$('#txtVehicle').val().trim(),
            'email'                 :$('#txtEmail').val().trim(),
            'type'                  :$('#optUserType').val(),
            'complex'               :$('#optComplex').val(),
            'active'                :1
        }

        var uAuth ={
            'pass1':$('#txtPassword').val(),
            'pass2':$('#txtPassword2').val()
        }
        
        firebase.auth().createUserWithEmailAndPassword(person.email, uAuth.pass1).then(function(user){
            console.log(user);
            console.log('authorized user '+user.user.uid);
            firebase.database().ref('users').child(user.user.uid).set(person).then(function(){
                console.log('registered user');
                var pic = $('#profilePic').val(), uploadname = '';
                var today = new Date();
                if(pic.length > 6){
                    console.log('uploading file snapshot');
                    //uploadname = user.user.uid+'_-_'+today.getFullYear()+'_'+today.getMonth()+'_'+today.getDate()+'_'+today.getHours()+'_'+today.getMinutes()+'_'+today.getSeconds();
                    uploadname = user.user.uid;
                    firebase.storage().ref('profile_pic'+'/'+uploadname).putString(pic, 'data_url').then(function(snapshot){
                        console.log('Uploaded a blob or file!');
                        firebase.database().ref('users/'+user.user.uid).child('profilepic').set(uploadname).then(function(){
                            console.log('saved file name');                           
                            firebase.database().ref('users/'+sessionStorage.uid).once('value',function(snap){
                                var uFrame = snap.val();
                                var today = Date.now();
                                if(snap.val() != null){
                                    var log = {
                                        'actor'         :sessionStorage.uid,
                                        'action'        :'register user',
                                        'description'   :uFrame.first_name+' '+uFrame.last_name+' ('+sessionStorage.uid+') '+' updated user '+person.first_name+' '+person.last_name+' ('+user.user.uid+')',
                                        'timestamp'     :today,
                                        'functionName'  :'user.register()'
                                    }
                                    firebase.database().ref('log').push(log).then(function(){
                                        console.log('updated log');
                                        $("#loading_div").hide();
                                        $("#success").show();
                                        setTimeout(function(){
                                            $("#success").fadeOut(700); 
                                        },5000);                                                                         
                                    }).catch(function(err){
                                        console.log('error');
                                        $("#loading_div").hide();
                                        $("#error").show();
                                        setTimeout(function(){
                                            $("#error").fadeOut(700); 
                                        },5000);
                                                                            
                                        console.log(err);
                                    });
                                }
                            }); 
                        });
                    }).catch(function(err){
                        console.log('error while uploading');
                        console.log(err);
                    });
                }
                else{
                    firebase.database().ref('users/'+sessionStorage.uid).once('value',function(snap){
                        var uFrame = snap.val();
                        var today = Date.now();
                        var log = {
                            'actor':sessionStorage.uid,
                            'action':'register user',
                            'description':uFrame.first_name+' '+uFrame.last_name+' ('+sessionStorage.uid+') '+' updated user '+person.first_name+' '+person.last_name+' ('+user.user.uid+')',
                            'timestamp':today,
                            'functionName':'user.register()'
                        }
                        // console.log(log)
                        firebase.database().ref('log').push(log).then(function(){
                            console.log('updated log');
                            $("#loading_div").hide();
                            $("#success").show();
                            setTimeout(function(){
                                $("#success").fadeOut(700); 
                            },5000);                                                         
                        }).catch(function(err){
                            console.log('error');
                            console.log(err);
                            $("#loading_div").hide();
                            $("#error").show();
                            setTimeout(function(){
                                $("#error").fadeOut(700); 
                            },5000);                                                             
                        });
                    });
                }                
            }).catch(function(error){
                console.log('error');
                $("#loading_div").hide();
                $("#error").show();
                setTimeout(function(){
                    $("#error").fadeOut(700); 
                },5000);
                                                
                console.log('failed to register user');
                console.log(error);
            });
        });
    },
    'validate':function(){
        var person = {
            'first_name'            :$('#txtName').val().trim(),
            'last_name'             :$('#txtSurname').val().trim(),
            'telephone'             :$('#txtTelephone').val().trim(),
            'id'                    :$('#txtIDNO').val().trim(),
            'street_address'        :$('#txtAddress').val().trim(),
            'vehicle_number'        :$('#txtVehicle').val().trim(),
            'email'                 :$('#txtEmail').val().trim(),
            'type'                  :$('#optUserType').val(),
            'complex'               :$('#optComplex').val()
        }
        
        var uAuth = {
            'pass1':$('#txtPassword').val(),
            'pass2':$('#txtPassword2').val()
        }
        
        var goto = true;
        var element = null;
        if(person.type == null)
            person.type = '';
        if(person.complex == null)
            person.complex = '';
        
        if(person.first_name == '' || person.first_name.length < 1){
            if(goto){
                $('#txtName').focus();
                goto = false;
            }
            $('#txtName').css('border-color','#e87979');
        }
        if(person.last_name == '' || person.last_name.length < 1){
            if(goto){
                $('#txtSurname').focus();
                goto = false;
            }
            $('#txtSurname').css('border-color','#e87979');
        }
        if(person.telephone == '' || person.telephone.length < 1){
            if(goto)
                $('#txtTelephone').focus();
            goto = false;
            $('#txtTelephone').css('border-color','#e87979');
        }
        if(person.id == '' || person.id.length < 1){
            if(goto)
                $('#txtIDNO').focus();
            goto = false;
            $('#txtIDNO').css('border-color','#e87979');
        }
        if(person.street_address == '' || person.street_address.length < 1){
            if(goto)
                $('#txtAddress').focus();
            goto = false;
            $('#txtAddress').css('border-color','#e87979');
        }
        /*if(person.vehicle_number == '' || person.vehicle_number.length < 1){
            if(goto)
                $('#txtVehicle').focus();
            goto = false;
        }*/
        if(person.email == '' || person.email.length < 1 || !validator.email(person.email)){
            if(goto){
                $('#txtEmail').focus();
                goto = false;
            }
            $('#txtEmail').css('border-color','#e87979');
            $("#loading_div").hide();
            $("#required_error").show();
            setTimeout(function(){
                $("#required_error").fadeOut(700); 
            },5000);
        }
        if(person.type == '' || person.type.length < 1){
            if(goto){
                $('#optUserType').focus();
                goto = false;
            }
            $('#optUserType').css('border-color','#e87979');
            $("#loading_div").hide();
            $("#required_error").show();
            setTimeout(function(){
                $("#required_error").fadeOut(700); 
            },5000);
        }
        if(person.complex == '' || person.complex.length < 1){
            if(goto){
                $('#optComplex').focus();
                goto = false;
            }
            $('#optComplex').css('border-color','#e87979');
            $("#loading_div").hide();
            $("#required_error").show();
            setTimeout(function(){
                $("#required_error").fadeOut(700); 
            },5000);
        }
        if(uAuth.pass1 == '' || uAuth.pass1.length < 6){
            if(goto){
                $('#txtPassword').focus();
                goto = false;
            }
            $('#txtPassword').css('border-color','#e87979');
            $("#loading_div").hide();
            $("#required_error").show();
            setTimeout(function(){
                $("#required_error").fadeOut(700); 
            },5000);
        }
        if(uAuth.pass2 == '' || uAuth.pass2.length < 6){
            if(goto){
                $('#txtPassword2').focus();
                goto = false;
            }
            $('#txtPassword2').css('border-color','#e87979');
                    $("#loading_div").hide();
                            $("#required_error").show();
                            setTimeout(function(){
                                $("#required_error").fadeOut(700); 
                            },5000);
        }
        if(uAuth.pass1 != uAuth.pass2)
        {
            if(goto){
                $('#txtPassword2').focus();
                goto = false;
            }
            $('#txtPassword2').css('border-color','#e87979');
                    $("#loading_div").hide();
                            $("#required_error").show();
                            setTimeout(function(){
                                $("#required_error").fadeOut(700); 
                            },5000);
        }
        
        setTimeout(function(){
            $('input, textarea, select').css('border-color','rgb(210, 214, 222)'); 
        },5000);
        
        if(goto){
            return true;   
        }else{
            return false;
        } 

    },
    'attachUserSave':function(){
        var main = this;
        $('#saveUser').click(function(){
            //console.log('saved');
            if(main.validate())
                main.register();
        });
    },
    fetchTypes:function(){
        var ukeys = [], utype = [], ckeys = [], ctype = [];
        firebase.database().ref('userType').once('value',function(snap){
            if(snap.val() == null){
                
            }
            else{
                ukeys = Object.keys(snap.val());
                utypes = snap.val();
                $('#optUserType').html('<option selected disabled="true" value="">User Type</option>');
                for(var k = 0; k < ukeys.length; k++){
                    if(ukeys[k] > 1 && ukeys[k] != 3)
                        $('#optUserType').append('<option value ="'+ukeys[k]+'">'+utypes[ukeys[k]]+'</option>');
                }
            }
        });
        
        console.log('then');
        firebase.database().ref('complex').orderByChild('name').once('value',function(snap){
            console.log(snap.val());
            if(snap.val() == null){
                console.log('no complexes');
            }
            else{
                ckeys = Object.keys(snap.val());
                ctypes = snap.val();
                console.log('keys');
                console.log(ckeys);
//                console.lof
                $('#optComplex').html('<option disabled="true" value="">Complex/Estate</option>');
                snap.forEach(function(childSnap){
                    var key_ = childSnap.key;
                    var obj = childSnap.val();
                    $('#optComplex').append('<option selected value ="'+obj.name+'">'+obj.name+'</option>');
                })
                // for(var k = 0; k < ckeys.length; k++){
                //     $('#optComplex').append('<option value ='+ctypes[ckeys[k]].name+'>'+ctypes[ckeys[k]].name+'</option>');
                // }
            }
        });
    },
    'populate':function(ukey){
        var userFrame = [];
        if(unkey.length > 5){
            firebase.database().ref("users/"+ukey).once('value',function(snap){
                if(snap.val() != null){
                    userFrame = snap.val();
                    $('#txtName').val(userFrame.first_name);
                    $('#txtSurname').val(userFrame.last_name);
                    $('#txtTelephone').val(userFrame.telephone);
                    $('#txtIDNO').val(userFrame.id);
                    $('#txtAddress').val(userFrame.street_address);
                    $('#txtVehicle').val(userFrame.vehicle_number);
                    //$('#txtEmail').val();
                    $('#optUserType').val(userFrame.type);
                    $('#optComplex').val(userFrame.complex);
                }
            });
        }        
    },
    'disableComplex':function(){
        firebase.database().ref('users/'+sessionStorage.uid).once('value',function(snap){
            if(snap.val() == null){
                console.log(sessionStorage.uid+' not found');
            }
            else{
                //$('#optComplex').attr('disabled',true);
                $('#optComplex').val(snap.val().complex);              
                console.log($('#optComplex').val());
            }
        });
    }
}