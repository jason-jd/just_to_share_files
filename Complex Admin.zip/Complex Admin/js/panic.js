$(document).ready(function(){
    load_panic();
});



function load_panic(){
    firebase.database().ref('panic').orderByChild("complex_name").equalTo(JSON.parse(sessionStorage.myComplex).name).on("child_added",function(qrcode_useSnap){
        var data = qrcode_useSnap.val();
           console.log(data) 
           
            firebase.database().ref('users').child(data.user_id).once("value").then((mySnap)=>{
                var me = mySnap.val();
                var fullname = me.first_name+' '+me.last_name;
                $('#example1').dataTable().fnAddData([data.timestamp, fullname,me.street_address, '<a href="https://www.google.com/maps/place/'+data.position.latitude+','+data.position.longitude+'" target="_blank" class="btn btn-block btn-primary">View Location</a>']);
            })
        
        $("#loading_div").hide();
    })
}