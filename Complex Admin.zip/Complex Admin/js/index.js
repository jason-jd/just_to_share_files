$(document).ready(function(){
    console.log('starting..');
    // complexAdminValidator.start();
    get_my_detail(sessionStorage.uid);
    load_stats()
});



function get_my_detail(uid){
    firebase.database().ref('users').child(sessionStorage.uid).once("value").then((mySnap)=>{
        var myDetail = mySnap.val();
        // sessionStorage.myDetail = JSON.stringify(myDetail)
        firebase.database().ref('complex').orderByChild("name").equalTo(myDetail.complex).once("value").then((complexSnap)=>{
            var my_complex = complexSnap.val();
            complexSnap.forEach(childSnap => {

                var key = childSnap.key;
                var childData = childSnap.val()
                // console.log(childData.name)
                $("#name").text(childData.name);
                sessionStorage.myComplex = JSON.stringify(childData)

            });
            return;
        })
    }).catch(function(error){
        console.log('error');
        console.log(error);
    });
}

var pho = {
    'start'  : function(){

    }
}

function load_stats(){
    var complex = JSON.parse(sessionStorage.myComplex).name;
    var num_of_visitors=0;
    var num_of_users=0;
    var num_of_panic=0;
    firebase.database().ref('qrcode').orderByChild("complex").equalTo(complex).on("child_added", function(mySnap){
        if(mySnap.val().visit_status==="enter"){
            num_of_visitors++;
        }
        $("#num_of_visitors").text(num_of_visitors);
    })

    firebase.database().ref('users').orderByChild("complex").equalTo(complex).on("child_added", function(mySnap){
        num_of_users++;
        $("#num_of_users").text(num_of_users);
    })
    firebase.database().ref('panic').orderByChild("complex_name").equalTo(complex).on("child_added", function(mySnap){
        num_of_panic++;
        $("#num_of_panic").text(num_of_panic);
    })
}