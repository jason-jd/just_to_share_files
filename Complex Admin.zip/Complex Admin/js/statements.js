$(document).ready(function(){
    console.log('hi');
    statement.start();

    $('#send-statement').click(function(){
        statement.send();
        $("#loading_div").show();
    });
});

var statement = {
    'start':function(){
        var main = this;
        main.fetch();
    },
    'fetch':function(){
        console.log('start');
        firebase.database().ref("users").once('value',function(snap){
            console.log('end');
            
            var identity = [], people = [], block = '';
            //$('#user-body').html('');
            if(snap.val() == null){
                console.log('nothing');
            }else{
                console.log('something');
                identity = Object.keys(snap.val());
                people = snap.val();
                //console.log(main);
                console.log(people);
                for(var k = 0; k < identity.length; k++){
                    if(people[identity[k]].type == 2 || people[identity[k]].type > 3){
                        for(var k = 0; k < identity.length; k++){
                            $('#optUser').append('<option value="'+identity[k]+'">'+people[identity[k]].first_name+' '+people[identity[k]].last_name+'</option>');
                        }
                        
                        /*block = "<tr>"
                                    +"<td>"+ people[identity[k]].id+"</td>"
                                    +"<td>"+ people[identity[k]].first_name+"</td>"
                                    +"<td>"+ people[identity[k]].last_name+"</td>"
                                    +"<td>"+ main.utype[people[identity[k]].type]+"</td>"
                                    +"<td>"+ people[identity[k]].complex+"</td>"
                                    +"<td>"+ people[identity[k]].street_address+"</td>"
                                    +"<td>"
                                        +'<a class="btn btn-info" id="user'+identity[k]+'">' 
                                            +'<i class="halflings-icon white edit"></i> Maintain'
                                        +'</a>'
                                    +"</td>"
                                +"</tr>";
                            $('#user-body').append(block);
                            main.attachEdit('user'+identity[k],identity[k]);*/
                    }
                }
            }
        });
    },
    'send':function(){
        
        /*
        firebase.auth().createUserWithEmailAndPassword(person.email, uAuth.pass1).then(function(user){
            console.log(user);
            console.log('authorized user '+user.user.uid);
            firebase.database().ref('users').child(user.user.uid).set(person).then(function(){
                console.log('registered user');
                var pic = $('#profilePic').val(), uploadname = '';
                var today = new Date();
                if(pic.length > 6){
                    console.log('uploading file snapshot');
                    //uploadname = user.user.uid+'_-_'+today.getFullYear()+'_'+today.getMonth()+'_'+today.getDate()+'_'+today.getHours()+'_'+today.getMinutes()+'_'+today.getSeconds();
                    uploadname = user.user.uid;
                    firebase.storage().ref('profile_pic'+'/'+uploadname).putString(pic, 'data_url').then(function(snapshot){
                        console.log('Uploaded a blob or file!');
                        firebase.database().ref('users/'+user.user.uid).child('profilepic').set(uploadname).then(function(){
                            console.log('saved file name');                           
                            firebase.database().ref('users/'+sessionStorage.uid).once('value',function(snap){
                                var uFrame = snap.val();
                                var today = Date.now();
                                if(snap.val() != null){
                                    var log = {
                                        'actor'         :sessionStorage.uid,
                                        'action'        :'register user',
                                        'description'   :uFrame.first_name+' '+uFrame.last_name+' ('+sessionStorage.uid+') '+' updated user '+person.first_name+' '+person.last_name+' ('+user.user.uid+')',
                                        'timestamp'     :today,
                                        'functionName'  :'user.register()'
                                    }
                                    firebase.database().ref('log').push(log).then(function(){
                                        console.log('updated log');
                                        $("#loading_div").hide();
                                        $("#success").show();
                                        setTimeout(function(){
                                            $("#success").fadeOut(700); 
                                        },5000);                                                                         
                                    }).catch(function(err){
                                        console.log('error');
                                        $("#loading_div").hide();
                                        $("#error").show();
                                        setTimeout(function(){
                                            $("#error").fadeOut(700); 
                                        },5000);
                                                                            
                                        console.log(err);
                                    });
                                }
                            }); 
                        });
                    }).catch(function(err){
                        console.log('error while uploading');
                        console.log(err);
                    });
                }
                else{
                    firebase.database().ref('users/'+sessionStorage.uid).once('value',function(snap){
                        var uFrame = snap.val();
                        var today = Date.now();
                        var log = {
                            'actor':sessionStorage.uid,
                            'action':'register user',
                            'description':uFrame.first_name+' '+uFrame.last_name+' ('+sessionStorage.uid+') '+' updated user '+person.first_name+' '+person.last_name+' ('+user.user.uid+')',
                            'timestamp':today,
                            'functionName':'user.register()'
                        }
                        // console.log(log)
                        firebase.database().ref('log').push(log).then(function(){
                            console.log('updated log');
                            $("#loading_div").hide();
                            $("#success").show();
                            setTimeout(function(){
                                $("#success").fadeOut(700); 
                            },5000);
                                                         
                        }).catch(function(err){
                            console.log('error');
                            console.log(err);
                            $("#loading_div").hide();
                            $("#error").show();
                            setTimeout(function(){
                                $("#error").fadeOut(700); 
                            },5000);
                                                             
                        });
                    });
                }                
            }).catch(function(error){
                console.log('error');
                $("#loading_div").hide();
                $("#error").show();
                setTimeout(function(){
                    $("#error").fadeOut(700); 
                },5000);
                                                
                console.log('failed to register user');
                console.log(error);
            });
        });*/

        //var hook = '';
        //firebase.database().ref('');

        var file = document.getElementById('txtPdf').files[0]; // use the Blob or File API
        console.log(file.name);
        var date = new Date();
        var stateText = $('#txtName').val();
        var mon = date.getMonth(), day = date.getDate();
        if(mon < 10)
            mon = '0'+mon;
        if(day < 10)
            day = '0'+day;
        var userId = $('#optUser').val();
        console.log(stateText+' - '+userId);
        var filepath = userId+'_'+date.getFullYear()+'_'+mon+'_'+day+'_'+date.getHours()+'_'+date.getMinutes()+'_'+date.getSeconds();
        console.log(filepath);
       
        
        var data = {
            'file'  :   filepath,
            'user'  :   userId,
            'text'  :   stateText
        }
        firebase.storage().ref().child('statements/'+filepath).put(file).then(function(){
            firebase.database().ref('statements/'+userId).push(data).then(function(){
               $("#loading_div").hide();
                         $("#success").show();
                setTimeout(function(){
                    $("#success").fadeOut(700); 
                        },5000);
            });
        });
        /*ref.put(file).then(function(snapshot) {
            console.log('Uploaded a blob or file!');
        });*/
        

    }
}