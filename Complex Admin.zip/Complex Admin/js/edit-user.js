$(document).ready(function(){
    userEditor.start();
});

var userEditor ={
    'start':function(){
        var main = this;
        $('#edit').hide();
        //$('#edit').Modal('hide');
        main.fetchTypes();
        main.update();
       $('#dismiss-edit').click(function(){
            $('#edit').hide();
       });
    },
    'oldimage':'',
    'utype':[],
    'ctype':[],
    'flag':{
        'types':{
            'usertype'  :false,
            'complex'   :false,
        },
        'reset'     :function(){
            var main = this;
            main.usertype = false;
            main.complex = false;
        },
        'signal'    :function(){
            var main = this;
            var ftypes = Object.keys(main.types);
            for(var k = 0; k < ftypes.length; k++){
                if(!main.types[ftypes[k]]){
                    return false;
                }
            }
            return true;
        }
    },
    'fetchTypes':function(){
        var ukeys = [], utype = [], ckeys = [], ctype = [];
        var main = this;
        main.flag.reset();
        firebase.database().ref('userType').on('value',function(snap){
            main.flag.types.usertype = true;
            if(snap.val() == null){
                main.flag.types.usertype = true;
            }
            else{
                ukeys = Object.keys(snap.val());
                utype = snap.val();
                main.utype = utype;
                $('#optUserType').html('<option selected disabled="true" value="">User Type</option>');
                for(var k = 0; k < ukeys.length; k++){
                    if(ukeys[k] > 1 && ukeys[k] != 3)
                        $('#optUserType').append('<option value ='+ukeys[k]+'>'+utype[ukeys[k]]+'</option>');
                }
            }
            //if(main.flag.signal())
                main.print();
        });
        
      /*  console.log('then');
        firebase.database().ref('complex').on('value',function(snap){
            main.flag.types.complex = true;
            console.log(snap.val());
            if(snap.val() == null){
                console.log('no complexes');
            }
            else{
                ckeys = Object.keys(snap.val());
                ctype = snap.val();
                main.ctype = ctype;
                console.log('keys');
                console.log(ckeys);
//                console.lof
                $('#optComplex').html('<option selected disabled="true" value="">Complex/Estate</option>');
                for(var k = 0; k < ckeys.length; k++){
                    $('#optComplex').append('<option value ='+ckeys[k]+'>'+ctype[ckeys[k]].name+'</option>');
                }
            }
            if(main.flag.signal())
                main.print();
        });*/
    },
    'print':function(){
        var main = this;
        firebase.database().ref("users").once('value',function(snap){
            var identity = [], people = [], block = '';
            $('#user-body').html('');
            if(snap.val() == null){

            }else{
                identity = Object.keys(snap.val());
                people = snap.val();
                console.log(main);
                console.log(people);
                for(var k = 0; k < identity.length; k++){
                    if(people[identity[k]].type == 2 || people[identity[k]].type > 3){
                        block = "<tr>"
                                    +"<td>"+ people[identity[k]].id+"</td>"
                                    +"<td>"+ people[identity[k]].first_name+"</td>"
                                    +"<td>"+ people[identity[k]].last_name+"</td>"
                                    +"<td>"+ main.utype[people[identity[k]].type]+"</td>"
                                    +"<td>"+ people[identity[k]].complex+"</td>"
                                    +"<td>"+ people[identity[k]].street_address+"</td>"
                                    +"<td>"
                                        +'<a class="btn btn-info" id="user'+identity[k]+'">' 
                                            +'<i class="halflings-icon white edit"></i> Maintain'
                                        +'</a>'
                                    +"</td>"
                                +"</tr>";
                            $('#user-body').append(block);
                        
                        $("#loading_div").hide();
                            main.attachEdit('user'+identity[k],identity[k]);
                    }
                }
            }
        });
    },
    'attachEdit':function(id,key){
        var main = this;
        $('#'+id).click(function(){
            main.populate(key);
        });
    },
    'populate':function(ukey){
        var userFrame = [];
        var main = this;
        console.log('checking');
        if(ukey.length > 5){
            firebase.database().ref("users/"+ukey).once('value',function(snap){
                console.log('returning');
                if(snap.val() != null){
                    userFrame = snap.val();
                    $('#userval').val(ukey);
                    $('#txtName').val(userFrame.first_name);
                    $('#txtSurname').val(userFrame.last_name);
                    $('#txtTelephone').val(userFrame.telephone);
                    $('#txtIDNO').val(userFrame.id);
                    $('#txtAddress').val(userFrame.street_address);
                    $('#txtVehicle').val(userFrame.vehicle_number);
                    //$('#txtEmail').val();
                    $('#optUserType').val(userFrame.type);
                    $('#optComplex').val(userFrame.complex);
                    main.oldimage = userFrame.profilepic;
                    if(userFrame.active == 1){
                        $('#chkActive').prop('checked',true);
                    }else if(userFrame.active == 0){
                        $('#chkActive').prop('checked',false);
                    }

                    if(typeof userFrame.profilepic === 'undefined'){
                        $('#my_profile_pic').attr('src','../../assets/noppp.png');
                    }else{
                        main.oldimage = userFrame.profilepic;
                        main.getProfileImage(userFrame.profilepic);
                    }
                    //console.log(userFrame);
                    $('#edit').show();                    
                    console.log('returned');
                }
            });
        } 
    },
    'update':function(){
        var main = this;
        $('#update-user').click(function(){
            $("#loading_div").show();
            if(main.validate()){
                $('#update-user').attr('disabled','true');
                var person = {
                    'first_name'            :$('#txtName').val().trim(),
                    'last_name'             :$('#txtSurname').val().trim(),
                    'telephone'             :$('#txtTelephone').val().trim(),
                    'id'                    :$('#txtIDNO').val().trim(),
                    'street_address'        :$('#txtAddress').val().trim(),
                    'vehicle_number'        :$('#txtVehicle').val().trim(),
                    'type'                  :$('#optUserType').val(),
                    'active'                :null
                }
                if(person.type == 0){

                }
                else{
                    person.complex = $('#optComplex').val();
                }
                //if($('#chkActive')
                if($('#chkActive').is(':checked')){
                    person.active = 1;
                }else{
                    person.active = 0;
                }
                console.log(person);
                var uid = $('#userval').val();
                //return;
                firebase.database().ref('users/'+uid).update(person).then(function(){
                    console.log('updated');
                    var pic = $('#profilePic').val(), uploadname = '';
                    if(pic.length > 10){
                        var today = new Date();
                        console.log('uploading file snapshot');
                        //uploadname = uid+'_-_'+today.getFullYear()+'_'+today.getMonth()+'_'+today.getDate()+'_'+today.getHours()+'_'+today.getMinutes()+'_'+today.getSeconds();
                        uploadname = uid;
                        firebase.storage().ref('profile_pic'+'/'+uploadname).putString(pic, 'data_url').then(function(snapshot){
                            console.log('Uploaded a blob or file!');
                            firebase.database().ref('users/'+uid).child('profilepic').set(uploadname).then(function(snap){
                                console.log('saved file name');
                                $('#update-user').removeAttr('disabled');
                                firebase.database().ref('users/'+sessionStorage.uid).once('value',function(snap){
                                    var uFrame = snap.val();
                                    var today = Date.now();
                                    if(snap.val() != null){
                                        log = {
                                            'actor':sessionStorage.uid,
                                            'action':'edit user',
                                            'description':uFrame.first_name+' '+uFrame.last_name+' ('+sessionStorage.uid+') '+' updated user '+person.first_name+' '+person.last_name+' ('+uid+')',
                                            'timestamp':today,
                                            'functionName':'userEditor.update()'
                                        }
                                        firebase.database().ref('log').push(log).then(function(){
                                            console.log('updated log');
                                                     $("#success").show();
                setTimeout(function(){
                    $("#success").fadeOut(700); 
                        },5000);                                      
                                    $("#loading_div").hide();
                                            location.reload()
                                            
                                        }).catch(function(err){
                                            console.log('error');
                                            console.log(err);
                                        });
                                    }else{
                                        console.log(sessionStorage.uid+' not found');
                                    }
                                }).catch(function(error){
                                    console.log('error');
                                    console.log(error);
                                });                                
                            });
                        }).catch(function(err){
                            console.log('error while uploading');
                            console.log(err);
                            $('#update-user').removeAttr('disabled');
                        });
                    }
                    else{
                        console.log('no image selected');
                        $('#update-user').removeAttr('disabled');
                        firebase.database().ref('users/'+sessionStorage.uid).once('value',function(snap){
                            var uFrame = snap.val();
                            var today = Date.now();
                            if(snap.val() != null){
                                log = {
                                    'actor':sessionStorage.uid,
                                    'action':'edit user',
                                    'description':uFrame.first_name+' '+uFrame.last_name+' ('+sessionStorage.uid+') '+' updated user '+person.first_name+' '+person.last_name+' ('+uid+')',
                                    'timestamp':today,
                                    'functionName':'userEditor.update()'
                                }
                                firebase.database().ref('log').push(log).then(function(){
                                    console.log('updated log');
         $("#success").show();
                setTimeout(function(){
                    $("#success").fadeOut(700); 
                        },5000);
                                    location.reload()
                                    $("#loading_div").hide();
                                }).catch(function(err){
                                    console.log('error');
                                    console.log(err);
                                });
                            }else{
                                console.log(sessionStorage.uid+' not found');
                            }
                        }).catch(function(error){
                            console.log('error');
                            console.log(error);
                            $("#loading_div").hide();
                        });
                    }                    
                }).catch(function(error){
                    $('#update-user').removeAttr('disabled');
                    console.log('error');
                    console.log('failed to update user');
                             $("#error").show();
                setTimeout(function(){
                    $("#error").fadeOut(700); 
                        },5000);  
                    $("#loading_div").hide();
                    console.log(error);
                });
            }else{
                console.log('invalid');
            }
        });
    },
    'validate':function(){
        var person = {
            'first_name'            :$('#txtName').val().trim(),
            'last_name'             :$('#txtSurname').val().trim(),
            'telephone'             :$('#txtTelephone').val().trim(),
            'id'                    :$('#txtIDNO').val().trim(),
            'streetAddress'         :$('#txtAddress').val().trim(),
            'vehicleRegistration'   :$('#txtVehicle').val().trim(),
            'type'                  :$('#optUserType').val(),
            'complex'               :$('#optComplex').val()
        }
        
        /*var uAuth = {
            'pass1':$('#txtPassword').val(),
            'pass2':$('#txtPassword2').val()
        }*/
        
        var goto = true;
        var element = null;
        if(person.type == null)
            person.type = '';
        if(person.complex == null)
            person.complex = '';
        
        if(person.first_name == '' || person.first_name.length < 1){
            if(goto)
                $('#txtName').focus();
            goto = false;
        }
        if(person.last_name == '' || person.last_name.length < 1){
            if(goto)
                $('#txtSurname').focus();
            goto = false;
        }
       /* if(person.telephone == '' || person.telephone.length < 1){
            if(goto)
                $('#txtTelephone').focus();
            goto = false;
        }
        if(person.id == '' || person.id.length < 1){
            if(goto)
                $('#txtIDNO').focus();
            goto = false;
        }
        if(person.streetAddress == '' || person.streetAddress.length < 1){
            if(goto)
                $('#txtAddress').focus();
            goto = false;
        }
        if(person.vehicleRegistration == '' || person.vehicleRegistration.length < 1){
            if(goto)
                $('#txtVehicle').focus();
            goto = false;
        }*/
        if(person.type == '' || person.type.length < 1){
            if(goto)
                $('#optUserType').focus();
            goto = false;
        }
        /*if(person.complex == '' || person.complex.length < 1){
            if(goto)
                $('#optComplex').focus();
            goto = false;
        }*/
        
        if(goto){
            return true;   
        }else{
            return false;
        }        
    },
    'getProfileImage':function(imgname){
        firebase.storage().ref('profile_pic/'+imgname).getDownloadURL().then(function(url){
            $('#my_profile_pic').attr('src',url);
        });
    }
}