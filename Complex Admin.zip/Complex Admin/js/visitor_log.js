$(document).ready(function(){
    get_my_detail(sessionStorage.uid)
    initiate();
    control();
});

function get_my_detail(uid){
    firebase.database().ref('users').child(sessionStorage.uid).once("value").then((mySnap)=>{
        var myDetail = mySnap.val();
        // sessionStorage.myDetail = JSON.stringify(myDetail)
        firebase.database().ref('complex').orderByChild("name").equalTo(myDetail.complex).once("value").then((complexSnap)=>{
            var my_complex = complexSnap.val();
            complexSnap.forEach(childSnap => {

                var key = childSnap.key;
                var childData = childSnap.val()
                // console.log(childData.name)
                $("#my_complex_name").text(childData.name);
                sessionStorage.myComplex = JSON.stringify(childData)

            });
            return
        })
    }).then(()=>{
        load_visitors();

    }).catch(function(error){
        console.log('error');
        console.log(error);
    });
}

function initiate(){
    var txt = "innerText" in HTMLElement.prototype ? "innerText" : "textContent";
    var scanner = new WebCodeCamJS("canvas");
    var arg = {
        resultFunction: function(result) {
            if(result.code.indexOf('=')>-1){
                var qrcode = result.code.split('=');
                checkCode(qrcode[0],qrcode[1]);
                scanner.pause();
                setTimeout(function(){scanner.play();}, 3000);
            }
            else{
                // alert("Kayd, Fuck off! Dont try to get in here")
            }

        }
    };
    scanner.init(arg).play(); 
}
function checkCode(bChild,cChild){
    if(cChild=="3"){
        // console.log(bChild)
        firebase.database().ref('qrcode').child(bChild).once("value").then((mySnap)=>{
            var my_code = mySnap.val();
            // console.log(my_code);
            if(my_code != null){
                if(my_code.complex == JSON.parse(sessionStorage.myComplex).name&&my_code.status=='active'){
                    var valid = false;
                    var to_update={};
                    if(my_code.type == "use" && my_code.uses>0){
                        to_update.uses = my_code.uses-1;
                        valid = true;
                    }
                    else if(my_code.type == "date"){
                        var start_date = new Date(my_code.start_date);
                        var end_date = new Date(my_code.end_date);
                        var now = Date.now();
                        if(start_date.getTime()<=now && end_date>=now){
                            valid = true;
                        }
                    }

                    
                    if(valid){
                        if(my_code.visit_status == "exit" || my_code.visit_status == "created"){
                            to_update.visit_status = "enter"
                        }
                        else if(my_code.visit_status == "enter"){
                            to_update.visit_status = "exit"
                        }
                        firebase.database().ref('qrcode').child(bChild).update(to_update);
                        var qrcode_use = {
                            timestamp: Date.now(),
                            status: to_update.visit_status,
                            complex: my_code.complex,
                            qrcode: my_code,
                            street_address: my_code.street_address
                        }
                        firebase.database().ref('qrcode_use').push(qrcode_use).then(()=>{
                            firebase.database().ref('users/'+my_code.receiver).once("value").then((userSnap)=>{
                                var user = userSnap.val();
                                var profile_pic = '../../assets/nop.png';
                                if(user.profile_pic != null && user.profile_pic != ''){
                                    profile_pic = user.profile_pic;
                                }
                                $("#Open").modal('show');
                                $("#profileUser").attr("src",profile_pic);
                                $("#userName").val(user.first_name);
                                $("#userSurname").val(user.last_name);
                                $("#userID").val(user.id);
                                $("#userVehicle").val(user.vehicle_number);
                                $("#successful").show();
                                $("#unsuccessful").hide();
                            })
                            
                        })
                    }
                    else{
                        $("#Open").modal('show');
                        $("#profileUser").attr("src","../../assets/nop.png");
                        $("#userName").val("");
                        $("#userSurname").val("");
                        $("#userID").val("");
                        $("#userVehicle").val("");
                        $("#successful").hide();
                        $("#unsuccessful").show();
                    }
                }
                
            }

        }).catch(function(error){
            $("#Open").modal('show');
            $("#profileUser").attr("src","../../assets/nop.png");
            $("#userName").val("");
            $("#userSurname").val("");
            $("#userID").val("");
            $("#userVehicle").val("");
            $("#successful").hide();
            $("#unsuccessful").show();
            console.log('error');
            console.log(error);
        });
    }
    else if(cChild=="2" || cChild=="5"){
        firebase.database().ref('users').child(bChild).once("value").then((mySnap)=>{
            var my_code = mySnap.val();
            var qrcode_use = {
                timestamp: Date.now(),
                status: "resident",
                complex: my_code.complex,
                street_address: my_code.street_address,
                name: my_code.first_name+" "+my_code.last_name,
                user_id:mySnap.key
            }
            firebase.database().ref('qrcode_use').push(qrcode_use).then(()=>{
                    var profile_pic = '../../assets/nop.png';
                    // if(user.profile_pic != null && user.profile_pic != ''){
                    //     profile_pic = user.profile_pic;
                    // }
                    $("#Open").modal('show');
                    $("#profileUser").attr("src",profile_pic);
                    $("#userName").val(my_code.first_name);
                    $("#userSurname").val(my_code.last_name);
                    $("#userID").val(my_code.id);
                    $("#userVehicle").val(my_code.vehicle_number);
                    $("#successful").show();
                    $("#unsuccessful").hide();
                
            })
           

        }).catch(function(error){
            $("#Open").modal('show');
            $("#profileUser").attr("src","../../assets/nop.png");
            $("#userName").val("");
            $("#userSurname").val("");
            $("#userID").val("");
            $("#userVehicle").val("");
            $("#successful").hide();
            $("#unsuccessful").show();
            console.log('error');
            console.log(error);
        });
    }
}

function control(){
    $("#successful").hide();
        // $("#canvas").hide();
        $("#canvas").show();
        $("#unsuccessful").hide();
        $("#example1").dataTable();
        $('#example2').dataTable({
          "bPaginate": true,
          "bLengthChange": false,
          "bFilter": false,
          "bSort": true,
          "bInfo": true,
          "bAutoWidth": false
        });
}

function viewProfile(obj){
    $('#openProfile').find('input').each(function(){
        $(this).val('');
    })
    var usrID = obj.getAttribute("data-userid");
    firebase.database().ref('users').child(usrID).once("value").then((userSnap)=>{
        var user = userSnap.val();
        if(user.profile_pic != null && user.profile_pic != ''){
            $("#profileUser").attr('src',user.profile_pic);
        }
        $("#nameUser").val(user.first_name);
        $("#surnameUser").val(user.last_name);
        // $("#Iduser").val(user.id);
        $("#VehicleUser").val(user.vehicle_number);
        $("#contact").val(user.telephone);


    }).catch(err=>{
        console.log(err);
    })
//     $.ajax({
//     url:"forViewProf.php",
//     method: "POST",
//     data: {myUser : usrID},
//     success:function (data) {

//         var asd = JSON.parse(data);
      
//         if(asd.profPic == null)
//       {
//           $("#profileUser").attr("src", "../../assets/nop.png");
//       }
//       else{
//           $("#profileUser").attr("src",asd.profPic);
//       }
//         $("#nameUser").val(asd.name);
//         $("#surnameUser").val(asd.surname);
//         $("#Iduser").val(asd.idNum);
//         $("#VehicleUser").val(asd.vehicle);
//         $("#contact").val(asd.contact);
//       $("#openProfile").modal('show');
//   },
//   error: function(a,b,c) {
//     alert(a.status + "\n" + b + "\n" + c);
//   }
//   });


}

function load_visitors(){
    firebase.database().ref('qrcode_use').orderByChild("complex").equalTo(JSON.parse(sessionStorage.myComplex).name).on("child_added",function(qrcode_useSnap){
        var data = qrcode_useSnap.val();
        // mySnap.forEach(snap=>{
        //     console.log(key)
            // var key = snap.key;
            // var data = snap.val();
        if(data.qrcode){
            firebase.database().ref('users').child(data.qrcode.receiver).once("value").then((mySnap)=>{
                var me = mySnap.val();
                var d = new Date(Number(data.timestamp));
                var fullname = me.first_name+' '+me.last_name;
                $('#example1').dataTable().fnAddData([d.toString(), data.status,fullname,data.street_address, '<button href="#" onclick="viewProfile(this);" data-toggle="modal" data-userid="'+data.qrcode.receiver+'" data-target="#openProfile" class="btn btn-block btn-primary">View Profile</button>']);
            })
        }
        else{
                var d = new Date(Number(data.timestamp));
                $('#example1').dataTable().fnAddData([d.toString(), data.status,data.name,data.street_address, '<button href="#" onclick="viewProfile(this);" data-toggle="modal" data-userid="'+data.user_id+'" data-target="#openProfile" class="btn btn-block btn-primary">View Profile</button>']);
        }
        
            
        // })
        
        // sessionStorage.myDetail = JSON.stringify(myDetail)
        
    })
}